﻿using System.Collections.Generic;

namespace SpaceShooter.Application.Core
{
    public class Formation
    {
        public List<Spawn> Columns = new List<Spawn>();
    }
}